package com.example.personalizedlearningexperienceapp;

import java.util.ArrayList;

public class DataSource {

    ///For Top Stories
    // Method to get titles of top stories
    public static ArrayList<String> geTopics1() {
        ArrayList<String> titleDataSource = new ArrayList<>();
        titleDataSource.add("Algorithms");
        titleDataSource.add("Web Development");
        titleDataSource.add("Algorithms");
        titleDataSource.add("Web Development");
        titleDataSource.add("Algorithms");
        titleDataSource.add("Web Development");
        titleDataSource.add("Algorithms");
        titleDataSource.add("Web Development");
        return titleDataSource;
    }

    public static ArrayList<String> geTopics2() {
        ArrayList<String> titleDataSource = new ArrayList<>();
        titleDataSource.add("Data Structures");
        titleDataSource.add("Testing");
        titleDataSource.add("Data Structures");
        titleDataSource.add("Testing");
        titleDataSource.add("Data Structures");
        titleDataSource.add("Testing");
        titleDataSource.add("Data Structures");
        titleDataSource.add("Testing");
        return titleDataSource;
    }


}
